<?php

$dbHost = "localhost";
$dbUser = "root";
$dbPass = "";
$dbName = "db_muslim";

$conn = mysqli_connect($dbHost, $dbUser, $dbPass, $dbName);
