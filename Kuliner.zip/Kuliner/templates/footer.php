<div class="row bg-primary">
    <div class="row p-5 text-light justify-content-center">
        <div class="col-md-6">
            <h2 class="text-light">Pusat<span class="fw-bold">Kulinerku</span></h2>
            <small>Web KulinerKudus disini menyediakan bergbagai Kuniner yang beragam</small>
            <small>WhatsApp : 085643903451</small>
        </div>
        <div class="col-md-4">
            <h2>Projects</h2>
            <small>PHP</small><br>
            <small>JQuery</small><br>
            <small>BootStrap V.5.3</small><br>
        </div>
    </div>
    <div class="row">
        <div class="col text-center mb-3">
            <small>Copyrigth @ 2023.Trafel Selfi</small>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</body>

</html>